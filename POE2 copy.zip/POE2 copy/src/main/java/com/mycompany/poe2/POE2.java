/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.poe2;
import java.util.Scanner;
/**
 *
 * @author apple
 */
public class POE2 {

    
    public static void main(String[] args) {
        Scanner myInput = new Scanner(System.in);
        Login myLog = new Login();
       //Declarations
       int choice;
       int messages = 0;
       int sendMessages = 0;
       int numMessages = 0;
     //login into the chatbox
     System.out.println("\nQuickChat");
     
     System.out.println("\nLogin");
     //promt the user to login
     System.out.print("Enter username");
     String usernameLogin = myInput.nextLine();
     System.out.print("Enter password ");
     String passwordLogin = myInput.nextLine();
     
     //
     System.out.println(myLog.returnLoginStatus(usernameLogin, passwordLogin));
    //if successful login  
    if (myLog.loginUser) {
    System.out.println("\nWelcome to QuickChat");
      
    System.out.print("How many messages would you like to send?");
    sendMessages = myInput.nextInt();
    
    //while statement
    while (true) {
        System.out.println("\n====MENU====");
        System.out.println("1. Send Messages");
        System.out.println("2. Show recently sent messages");
        System.out.println("3. Quit");
        //Prompt the user for a choice
        System.out.println("Choose an option(1 to 3)");
        choice = myInput.nextInt();
        
        //switch statement for choice o
        switch(choice) {
            case 1:
                int left = sendMessages - numMessages;
                if(left <= 0) {
                    System.out.println("You have already entered all" + sendMessages + "messages.");
                break;
                }
                for(int i = 0; i < left;i++) {
                    sendMessagers();
                    sendMessages++;
                }
            case 2:
                System.out.println("Coming soon. ");
                break;
            case 3:
                System.out.println("Goodbye. ");
            default:
                System.out.println("Invalid Option. Please choose option 1,2, or 3.");
        }
    }
  }
    
}
    public static void sendMessagers() {
        Scanner myInput = new Scanner(System.in);
        int messageNumber ;
        System.out.println("\n--- New Message (#" + messageNumber + ") ----");
        String recipient;
        while(true) {
            System.out.print("Enter recipient cell phone number");
            recipient = myInput.nextLine();
            Message mS = new Message("0000000000", messageNumber,recipient, "");
            String result = mS.checkRecipentCell();
            System.out.println(result);
            if (result.equals("Cell phone number successfully captured.")) {
                break;
            }
        }
        String messageChat;
        while(true) {
            System.out.println("Enter your message");
            messageChat = myInput.nextLine();
            Message mS = new Message("0000000000", messageNumber, recipient, messageChat);
            String result = mS.messageLength();
            System.out.println(result);
            if (result.equals("Message ready to send")) {
                break;
            }
        }
        Message mm = new Message(messageNumber, recipient, messageChat);
        System.out.println("\nWhat would you like to do with this message?");
        System.out.println("1. Send Message");
        System.out.println("2. Disregard Message");
        System.out.println("3. Store Message");
        System.out.println(Choose an option);
        int choice = myInput.nextInt();
       System.out.println(mm.sendMessage());
}



}